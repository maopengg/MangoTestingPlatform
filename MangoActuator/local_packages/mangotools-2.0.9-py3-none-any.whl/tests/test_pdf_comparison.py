"""Deterministic PDF fixtures exercise the public assertion API on Python 3.10."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock

import numpy as np
import pymupdf
from PIL import Image

from mangotools.assertion import MangoAssertion, FileAssertion, FileVisualAssertion, PdfComparisonAssertion
from mangotools.assertion.visual._pdf_comparison_engine import (
    compare_characters, compare_masks, compare_pdfs, evaluate_report, parse_inputs,
)
from mangotools.decorator import func_info


class TestPdfComparison(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.assertion = MangoAssertion()
        self.baseline = self.pdf('baseline', ['Mango comparison'])

    def pdf(self, name, pages, x=30, y=40, size=12, width=240, rotation=0):
        path = self.root / f'{name}.pdf'
        with pymupdf.open() as doc:
            for text in pages:
                page = doc.new_page(width=width, height=180)
                if text:
                    page.insert_text((x, y), text, fontsize=size)
                page.set_rotation(rotation)
            doc.save(path)
        return str(path)

    def ass(self, method='assert_pdf_comparison_pass', actual=None, **limits):
        return self.assertion.ass(method, {'文件路径': actual or self.baseline},
                                  {'基准文件路径': self.baseline, **limits})

    def report(self, actual=None, mode='all', **limits):
        a, b, config = parse_inputs({'文件路径': actual or self.baseline},
                                    {'基准文件路径': self.baseline, **limits})
        report = compare_pdfs(a, b, config, mode)
        evaluate_report(report, config)
        return report

    def test_identical_pdf_passes_all_four_methods(self):
        for method in ('assert_pdf_comparison_pass', 'assert_pdf_visual_match',
                       'assert_pdf_text_match', 'assert_pdf_layout_match'):
            with self.subTest(method=method):
                self.assertIn('PDF对比通过', self.ass(method))

    def test_json_parameters_and_plain_path(self):
        self.assertIn('通过', self.assertion.ass('assert_pdf_comparison_pass',
            json.dumps({'文件路径': self.baseline}), json.dumps({'基准文件路径': self.baseline})))
        self.assertIn('通过', FileVisualAssertion.assert_pdf_visual_match(
            self.baseline, {'基准文件路径': self.baseline}))

    def test_registration_and_parameter_fields(self):
        category = next(c for c in func_info if c['value'] == '文件视觉识别')
        group = next(c for c in category['children'] if c['value'] == 'PDF对比断言')
        self.assertEqual(len(group['children']), 5)
        file_category = next(c for c in func_info if c['value'] == '文件断言')
        file_methods = {m['value'] for c in file_category['children'] for m in c['children']}
        self.assertTrue(file_methods.isdisjoint(m['value'] for m in group['children']))
        for item in group['children']:
            self.assertTrue(hasattr(FileVisualAssertion, item['value']))
            self.assertFalse(hasattr(FileAssertion, item['value']))
            self.assertTrue(hasattr(PdfComparisonAssertion, item['value']))
            self.assertEqual([p['f'] for p in item['parameter']], ['actual', 'expect'])
            for parameter in item['parameter']:
                self.assertEqual(parameter['input_type'], 'object')
                self.assertTrue(parameter['object_fields'])

    def test_missing_text_and_visual_difference(self):
        path = self.pdf('missing', ['Mango'])
        with self.assertRaisesRegex(AssertionError, '文字新增/删除/替换'):
            self.ass('assert_pdf_text_match', path)
        with self.assertRaisesRegex(AssertionError, '墨迹差异率'):
            self.ass('assert_pdf_visual_match', path)

    def test_page_count_and_geometry_are_not_automatically_aligned(self):
        for name, path in [('pages', self.pdf('pages', ['Mango comparison', 'extra'])),
                           ('size', self.pdf('size', ['Mango comparison'], width=241)),
                           ('rotation', self.pdf('rotation', ['Mango comparison'], rotation=90))]:
            with self.subTest(name=name), self.assertRaises(AssertionError):
                self.ass(actual=path)

    def test_position_and_font_changes(self):
        path = self.pdf('shift', ['Mango comparison'], x=34)
        report = self.report(path, mode='layout')
        self.assertGreater(report['text_layout']['counts']['position_shift'], 0)
        with self.assertRaisesRegex(AssertionError, 'position_shift'):
            self.ass('assert_pdf_layout_match', path)
        self.assertIn('通过', self.ass('assert_pdf_layout_match', path, 最大位移字符数=100))
        self.assertIn('通过', self.ass('assert_pdf_text_match', path))
        path = self.pdf('font', ['Mango comparison'], size=13)
        self.assertGreater(self.report(path, mode='layout')['text_layout']['counts']['font_size_change'], 0)

    def test_line_wrap_detects_boundaries_not_characters(self):
        path = self.pdf('wrapped', ['Mango\ncomparison'])
        counts = self.report(path, mode='layout')['text_layout']['counts']
        self.assertEqual(counts['text_change'], 0)
        self.assertEqual(counts['line_wrap'], 1)
        with self.assertRaisesRegex(AssertionError, 'line_wrap'):
            self.ass('assert_pdf_layout_match', path)

    def test_cross_page_flow(self):
        self.baseline = self.pdf('flow_base', ['Mango comparison', 'Tail'])
        path = self.pdf('flow_actual', ['Mango', 'comparison Tail'])
        counts = self.report(path, mode='layout')['text_layout']['counts']
        self.assertEqual(counts['text_change'], 0)
        self.assertEqual(counts['page_flow'], len('comparison'))

    def test_matching_blank_pages_pass_all_modes(self):
        for pages in ([''], ['Mango', '', 'Tail']):
            self.baseline = self.pdf('blank', pages)
            for method in ('assert_pdf_comparison_pass', 'assert_pdf_visual_match',
                           'assert_pdf_text_match', 'assert_pdf_layout_match', 'assert_pdf_color_match'):
                with self.subTest(pages=pages, method=method):
                    self.assertIn('通过', self.ass(method))

    def test_scanned_page_visual_passes_but_no_ocr(self):
        path = self.root / 'scan.pdf'
        pix = pymupdf.open(self.baseline)
        self.addCleanup(pix.close)
        with pymupdf.open() as doc:
            page = doc.new_page(width=240, height=180)
            page.insert_image(page.rect, pixmap=pix[0].get_pixmap())
            doc.save(path)
        self.baseline = str(path)
        self.assertIn('通过', self.ass('assert_pdf_visual_match'))
        with self.assertRaisesRegex(AssertionError, '不执行OCR'):
            self.ass()

    def test_masks_dilation_and_area_formula(self):
        baseline = np.zeros((8, 8), dtype=bool)
        baseline[3, 3] = True
        actual = np.zeros_like(baseline)
        actual[4, 4] = True
        metrics, _, _ = compare_masks(actual, baseline)
        self.assertEqual(metrics['unmatched_ink_pixels'], 0)
        actual[:] = False
        actual[5, 5] = True
        metrics, a, b = compare_masks(actual, baseline)
        self.assertEqual(metrics['unmatched_ink_pixels'], 2)
        self.assertEqual(metrics['ink_difference_ratio'], 1)
        self.assertAlmostEqual(metrics['unmatched_area_pt2'], 2 / 9)
        self.assertEqual(int(a.sum() + b.sum()), 2)
        with self.assertRaisesRegex(ValueError, '尺寸不一致'):
            compare_masks(actual, baseline[:2])

    def test_empty_masks_and_single_missing_ink(self):
        mask = np.zeros((5, 5), dtype=bool)
        self.assertEqual(compare_masks(mask, mask)[0]['ink_difference_ratio'], 0)
        other = mask.copy()
        other[2, 2] = True
        self.assertEqual(compare_masks(mask, other)[0]['ink_difference_ratio'], 1)

    def test_ink_threshold_is_strictly_below_225(self):
        from mangotools.assertion.visual._pdf_comparison_engine import _mask
        page = MagicMock()
        page.get_pixmap.return_value = MagicMock(samples=bytes([224, 225, 226, 0]), height=1, width=3, stride=4)
        mask = _mask(page, np, pymupdf)
        self.assertEqual(mask.tolist(), [[True, False, False]])
        page.get_pixmap.assert_called_once_with(dpi=216, colorspace=pymupdf.csGRAY, alpha=False)

    def test_identical_repeated_text_uses_linear_alignment(self):
        chars = [{'text': 'A', 'page': 1, 'line': 0, 'origin': [10, 10], 'size': 12}] * 20000
        with patch('mangotools.assertion.visual._pdf_comparison_engine.SequenceMatcher') as matcher:
            result = compare_characters(chars, chars)
        matcher.assert_not_called()
        self.assertTrue(all(value == 0 for value in result['counts'].values()))

    def test_exact_layout_thresholds(self):
        baseline = [{'text': 'A', 'page': 1, 'line': 0, 'origin': [10, 10], 'size': 12}]
        actual = [{**baseline[0], 'origin': [13, 10], 'size': 12.75}]
        counts = compare_characters(actual, baseline)['counts']
        self.assertEqual(counts['position_shift'], 0)
        self.assertEqual(counts['font_size_change'], 0)
        actual[0].update(origin=[13.001, 10], size=12.751)
        counts = compare_characters(actual, baseline)['counts']
        self.assertEqual(counts['position_shift'], 1)
        self.assertEqual(counts['font_size_change'], 1)
        actual[0]['page'] = 2
        counts = compare_characters(actual, baseline)['counts']
        self.assertEqual(counts['page_flow'], 1)
        self.assertEqual(counts['position_shift'], 0)

    def test_insertion_does_not_shift_all_following_matches(self):
        def chars(text):
            return [{'text': c, 'page': 1, 'line': 0, 'origin': [0, 0], 'size': 12} for c in text]
        result = compare_characters(chars('prefix NEW repeated repeated suffix'),
                                    chars('prefix repeated repeated suffix'))
        self.assertEqual(result['counts']['text_change'], 4)
        self.assertEqual(result['counts']['position_shift'], 0)

    def test_reports_and_failure_diff_images(self):
        path = self.pdf('report_shift', ['Mango comparison'], x=38)
        report = self.report(path, 输出目录=str(self.root / 'reports'))
        saved = json.loads(Path(report['report_path']).read_text())
        self.assertFalse(saved['passed'])
        self.assertEqual(saved['versions']['numpy'], '2.2.6')
        with Image.open(saved['pages'][0]['diff_image']) as image:
            self.assertEqual(image.mode, 'RGB')
            self.assertEqual(image.size, (720, 540))
        with self.assertRaisesRegex(AssertionError, '报告='):
            self.ass(actual=path, 输出目录=str(self.root / 'reports'))
        passed = self.report(输出目录=str(self.root / 'reports'))
        self.assertTrue(json.loads(Path(passed['report_path']).read_text())['passed'])
        self.assertNotIn('diff_image', passed['pages'][0])

    def test_visual_thresholds_are_applied_per_page(self):
        path = self.pdf('tolerated', ['Mango comparison'], x=38)
        report = self.report(path, mode='visual')
        metrics = report['pages'][0]
        self.assertIn('通过', self.ass('assert_pdf_visual_match', path,
            最大墨迹差异率=metrics['ink_difference_ratio'], 最大未匹配面积=metrics['unmatched_area_pt2']))
        with self.assertRaises(AssertionError):
            self.ass('assert_pdf_visual_match', path, 最大墨迹差异率=1, 最大未匹配面积=0)
        self.baseline = self.pdf('multi_base', ['Mango comparison'] * 4)
        path = self.pdf('multi_changed', ['Missing'] + ['Mango comparison'] * 3)
        report = self.report(path, mode='visual')
        mean = report['visual_summary']['ink_difference_ratio']
        self.assertGreater(report['pages'][0]['ink_difference_ratio'], mean)
        with self.assertRaises(AssertionError):
            self.ass('assert_pdf_visual_match', path, 最大墨迹差异率=mean, 最大未匹配面积=100000)

    def test_invalid_configuration(self):
        for config in ({'最大墨迹差异率': 1.1}, {'最大位移字符数': 1.5},
                       {'最大未匹配面积': -1}, {'最大未匹配面积': float('nan')},
                       {'最大跨页字符数': True}, {'最大跨页字符数': None},
                       {'错误参数': 1}, {'输出目录': ''}):
            with self.subTest(config=config), self.assertRaises(ValueError):
                self.ass(**config)
        with self.assertRaises(ValueError):
            parse_inputs({}, {})
        with self.assertRaises(ValueError):
            parse_inputs(self.baseline, 'not json')

    def test_missing_corrupt_non_pdf_and_encrypted_files(self):
        corrupt = self.root / 'corrupt.pdf'
        corrupt.write_bytes(b'not a pdf')
        image = self.root / 'image.png'
        Image.new('L', (10, 10), 255).save(image)
        encrypted = self.root / 'locked.pdf'
        with pymupdf.open(self.baseline) as doc:
            doc.save(encrypted, encryption=pymupdf.PDF_ENCRYPT_AES_256, owner_pw='owner', user_pw='secret')
        for path in (self.root / 'missing.pdf', corrupt, image, encrypted):
            with self.subTest(path=path), self.assertRaisesRegex(ValueError, 'PDF比较无法完成'):
                self.ass(actual=str(path))

    @patch('mangotools.assertion.visual._pdf_comparison_engine.requests.get')
    def test_url_download_and_temporary_cleanup(self, get):
        response = MagicMock()
        response.iter_content.return_value = [Path(self.baseline).read_bytes()]
        get.return_value.__enter__.return_value = response
        self.assertIn('通过', self.ass(actual='https://example.com/actual.pdf'))
        response.raise_for_status.assert_called_once()
        self.assertEqual(get.call_args.kwargs, {'timeout': 30, 'stream': True})
        from mangotools.assertion.visual._pdf_comparison_engine import _source_path
        with _source_path('https://example.com/a.pdf') as path:
            saved_path = path
            self.assertTrue(path.exists())
        self.assertFalse(saved_path.exists())

    @patch('mangotools.assertion.visual._pdf_comparison_engine.requests.get')
    def test_download_error_has_clear_reason(self, get):
        import requests
        get.side_effect = requests.ConnectionError('unreachable')
        with self.assertRaisesRegex(ValueError, 'unreachable'):
            self.ass(actual='https://example.com/a.pdf')

    def test_missing_dependency_error_is_actionable(self):
        import builtins
        original = builtins.__import__
        def missing(name, *args, **kwargs):
            if name == 'pymupdf':
                raise ImportError('not installed')
            return original(name, *args, **kwargs)
        with patch('builtins.__import__', side_effect=missing):
            with self.assertRaisesRegex(ValueError, '请重新安装 mangotools'):
                self.ass()


if __name__ == '__main__':
    unittest.main()
