"""PDF comparison primitives. Imaging dependencies are loaded on demand."""
import json
import math
import tempfile
from contextlib import ExitStack, contextmanager
from difflib import SequenceMatcher
from importlib.metadata import version
from pathlib import Path
from urllib.parse import urlparse

import requests

DPI = 216
INK_THRESHOLD = 225
POSITION_TOLERANCE_PT = 3.0
FONT_TOLERANCE_PT = 0.75
LIMITS = {
    '最大颜色差异率': 0,
    '最大颜色差异面积': 0,
    '颜色通道容差': 0,
    '最大墨迹差异率': 0,
    '最大未匹配面积': 0,
    '最大跨页字符数': 0,
    '最大换行变化数': 0,
    '最大位移字符数': 0,
    '最大字号变化字符数': 0,
}


def _dependencies():
    try:
        import pymupdf
        import numpy as np
        from PIL import Image, ImageFilter
    except ImportError as error:
        raise ValueError('文件对比依赖缺失，请重新安装 mangotools 及其默认依赖（Python 3.10+）') from error
    return pymupdf, np, Image, ImageFilter


def _json_object(value, label):
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except json.JSONDecodeError as error:
            raise ValueError(f'{label}必须是JSON对象') from error
    if not isinstance(value, dict):
        raise ValueError(f'{label}必须是JSON对象')
    return value


def parse_inputs(actual, expect):
    if isinstance(actual, str) and not actual.lstrip().startswith('{'):
        source = actual
    else:
        source = _json_object(actual, '实际值').get('文件路径')
    config = _json_object(expect, '预期值').copy()
    baseline = config.get('基准文件路径')
    for label, value in [('文件路径', source), ('基准文件路径', baseline)]:
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f'{label}不能为空且必须是字符串')
    unknown = set(config) - set(LIMITS) - {'基准文件路径', '输出目录'}
    if unknown:
        raise ValueError(f'不支持的比较参数：{", ".join(sorted(unknown))}')
    for key, default in LIMITS.items():
        value = config.get(key, default)
        try:
            number = float(value)
        except (TypeError, ValueError) as error:
            raise ValueError(f'{key}必须是非负数字') from error
        if isinstance(value, bool) or not math.isfinite(number) or number < 0:
            raise ValueError(f'{key}必须是非负有限数字')
        if key.endswith('数') and not number.is_integer():
            raise ValueError(f'{key}必须是非负整数')
        if key in {'最大墨迹差异率', '最大颜色差异率'} and number > 1:
            raise ValueError(f'{key}必须在0到1之间')
        if key == '颜色通道容差' and (number > 255 or not number.is_integer()):
            raise ValueError('颜色通道容差必须是0到255的整数')
        config[key] = number
    if '输出目录' in config and (not isinstance(config['输出目录'], str) or not config['输出目录'].strip()):
        raise ValueError('输出目录必须是非空路径字符串')
    return source.strip(), baseline.strip(), config


@contextmanager
def _source_path(source):
    if urlparse(source).scheme in {'http', 'https'}:
        with tempfile.TemporaryDirectory(prefix='mango-pdf-') as directory:
            path = Path(directory) / 'document.pdf'
            with requests.get(source, timeout=30, stream=True) as response:
                response.raise_for_status()
                with path.open('wb') as output:
                    for chunk in response.iter_content(chunk_size=1024 * 1024):
                        output.write(chunk)
            yield path
    else:
        path = Path(source).expanduser().resolve()
        if not path.is_file():
            raise ValueError(f'文件不存在：{path}')
        yield path


def compare_masks(actual_mask, baseline_mask):
    """Symmetric unmatched ink after a one-pixel Chebyshev dilation."""
    _, np, Image, ImageFilter = _dependencies()
    if actual_mask.shape != baseline_mask.shape:
        raise ValueError('墨迹掩码尺寸不一致')
    expanded_actual = np.asarray(Image.fromarray(actual_mask.astype(np.uint8) * 255).filter(ImageFilter.MaxFilter(3))) > 0
    expanded_baseline = np.asarray(Image.fromarray(baseline_mask.astype(np.uint8) * 255).filter(ImageFilter.MaxFilter(3))) > 0
    actual_residual = actual_mask & ~expanded_baseline
    baseline_residual = baseline_mask & ~expanded_actual
    residual = int(actual_residual.sum()) + int(baseline_residual.sum())
    denominator = int(actual_mask.sum()) + int(baseline_mask.sum())
    return {
        'unmatched_ink_pixels': residual,
        'ink_difference_ratio': residual / denominator if denominator else 0.0,
        'unmatched_area_pt2': residual * (72 / DPI) ** 2,
        'ink_pixels': denominator,
    }, actual_residual, baseline_residual


def _mask(page, np, pymupdf):
    pixmap = page.get_pixmap(dpi=DPI, colorspace=pymupdf.csGRAY, alpha=False)
    # Respect row stride rather than assuming tightly packed pixel storage.
    pixels = np.frombuffer(pixmap.samples, dtype=np.uint8).reshape(pixmap.height, pixmap.stride)
    return pixels[:, :pixmap.width] < INK_THRESHOLD


def _rgb(page, np, pymupdf):
    pixmap = page.get_pixmap(dpi=DPI, colorspace=pymupdf.csRGB, alpha=False)
    rows = np.frombuffer(pixmap.samples, dtype=np.uint8).reshape(pixmap.height, pixmap.stride)
    return rows[:, :pixmap.width * 3].reshape(pixmap.height, pixmap.width, 3)


def compare_rgb(actual, baseline, tolerance=0):
    """Compare RGB intensity at identical coordinates, including pale imagery."""
    _, np, _, _ = _dependencies()
    if actual.shape != baseline.shape:
        raise ValueError('RGB图像尺寸不一致')
    delta = np.abs(actual.astype(np.int16) - baseline.astype(np.int16)).max(axis=2)
    changed = delta > tolerance
    content = np.any(actual != 255, axis=2) | np.any(baseline != 255, axis=2)
    count, denominator = int(changed.sum()), int(content.sum())
    return {
        'color_difference_pixels': count,
        'color_difference_ratio': count / denominator if denominator else 0.0,
        'color_difference_area_pt2': count * (72 / DPI) ** 2,
        'max_channel_difference': int(delta.max()),
    }, changed


def _characters(page, page_index):
    characters = []
    for block in page.get_text('rawdict')['blocks']:
        for line in block.get('lines', []):
            line_id = len(characters)
            for span in line['spans']:
                for char in span['chars']:
                    # Whitespace positions vary across engines; line breaks are
                    # compared independently through adjacent aligned characters.
                    if char['c'].isspace():
                        continue
                    characters.append({
                        'text': char['c'], 'page': page_index + 1,
                        'line': line_id, 'origin': list(char['origin']),
                        'bbox': list(char['bbox']), 'size': span['size'],
                    })
    return characters


def compare_characters(actual, baseline):
    """Align document-wide text before attributing geometry changes."""
    a_text = ''.join(item['text'] for item in actual)
    b_text = ''.join(item['text'] for item in baseline)
    # Identical long documents (often full of repeated table cells) must not
    # pay SequenceMatcher's quadratic matching cost.
    opcodes = [('equal', 0, len(b_text), 0, len(a_text))] if a_text == b_text else (
        SequenceMatcher(None, b_text, a_text, autojunk=False).get_opcodes()
    )
    counts = dict.fromkeys(['text_change', 'page_flow', 'line_wrap', 'position_shift', 'font_size_change'], 0)
    details = []
    previous = None
    for tag, b_start, b_end, a_start, a_end in opcodes:
        if tag != 'equal':
            counts['text_change'] += max(b_end - b_start, a_end - a_start)
            details.append({'type': 'text_change', 'operation': tag,
                            'baseline': b_text[b_start:b_end], 'actual': a_text[a_start:a_end],
                            'baseline_offset': b_start, 'actual_offset': a_start})
            previous = None
            continue
        for offset in range(a_end - a_start):
            ai, bi = a_start + offset, b_start + offset
            a, b = actual[ai], baseline[bi]
            changes = []
            if a['page'] != b['page']:
                changes.append('page_flow')
            elif math.dist(a['origin'], b['origin']) > POSITION_TOLERANCE_PT:
                changes.append('position_shift')
            if abs(a['size'] - b['size']) > FONT_TOLERANCE_PT:
                changes.append('font_size_change')
            if previous is not None:
                pa, pb = previous
                a_break = (a['page'], a['line']) != (pa['page'], pa['line'])
                b_break = (b['page'], b['line']) != (pb['page'], pb['line'])
                if a_break != b_break:
                    changes.append('line_wrap')
            for change in changes:
                counts[change] += 1
                details.append({'type': change, 'actual': a, 'baseline': b})
            previous = a, b
    return {'counts': counts, 'details': details,
            'actual_characters': len(actual), 'baseline_characters': len(baseline),
            'alignment': 'SequenceMatcher, whitespace excluded, repeated text matched by context'}


def _write_diff(path, a_residual, b_residual, np, Image):
    pixels = np.full((*a_residual.shape, 3), 255, dtype=np.uint8)
    pixels[a_residual] = [220, 40, 40]
    pixels[b_residual] = [40, 80, 220]
    pixels[a_residual & b_residual] = [180, 40, 180]
    Image.fromarray(pixels).save(path)


def compare_pdfs(actual_source, baseline_source, config, mode='all'):
    """Return metrics; keep only one page pair's raster arrays in memory."""
    if mode not in {'all', 'visual', 'text', 'layout', 'color'}:
        raise ValueError(f'未知比较模式：{mode}')
    pymupdf, np, Image, _ = _dependencies()
    output = None
    if config.get('输出目录'):
        root = Path(config['输出目录']).expanduser().resolve()
        root.mkdir(parents=True, exist_ok=True)
        output = Path(tempfile.mkdtemp(prefix='pdf-comparison-', dir=root))
    report = {
        'mode': mode, 'actual': actual_source, 'baseline': baseline_source,
        'parameters': {'dpi': DPI, 'ink_threshold': INK_THRESHOLD, 'dilation_radius_px': 1,
                       'position_tolerance_pt': POSITION_TOLERANCE_PT, 'font_tolerance_pt': FONT_TOLERANCE_PT,
                       'limits': {key: config[key] for key in LIMITS}},
        'versions': {name: version(name) for name in ('pymupdf', 'Pillow', 'numpy')},
        'pages': [], 'structural_errors': [], 'text_unavailable_pages': [],
    }
    all_actual, all_baseline = [], []
    try:
        with ExitStack() as stack:
            a_path = stack.enter_context(_source_path(actual_source))
            b_path = stack.enter_context(_source_path(baseline_source))
            a_doc = stack.enter_context(pymupdf.open(a_path))
            b_doc = stack.enter_context(pymupdf.open(b_path))
            if not a_doc.is_pdf or not b_doc.is_pdf:
                raise ValueError('文件对比首期仅支持PDF文件')
            if a_doc.needs_pass or b_doc.needs_pass:
                raise ValueError('不支持需要密码的PDF文件')
            report['actual_page_count'], report['baseline_page_count'] = len(a_doc), len(b_doc)
            if len(a_doc) != len(b_doc):
                report['structural_errors'].append(f'页数不一致：实际={len(a_doc)}，基准={len(b_doc)}')
            for index in range(max(len(a_doc), len(b_doc))):
                a_page = a_doc[index] if index < len(a_doc) else None
                b_page = b_doc[index] if index < len(b_doc) else None
                page_report = {'page': index + 1}
                blank = {}
                for side, page in [('actual', a_page), ('baseline', b_page)]:
                    if page is not None:
                        rgb = _rgb(page, np, pymupdf)
                        blank[side] = bool(np.all(rgb == 255))
                        del rgb
                page_report['blank_pages'] = blank
                if len(blank) == 2 and blank['actual'] != blank['baseline']:
                    report['structural_errors'].append(f'第{index + 1}页异常空白：仅一侧为空白页')
                if mode not in {'visual', 'color'}:
                    for side, page, chars in [('actual', a_page, all_actual), ('baseline', b_page, all_baseline)]:
                        if page is None:
                            continue
                        items = _characters(page, index)
                        chars.extend(items)
                        # A blank or image-only page cannot establish text equivalence.
                        if not items and not (blank.get('actual') and blank.get('baseline')):
                            report['text_unavailable_pages'].append({'side': side, 'page': index + 1})
                if a_page is None or b_page is None:
                    page_report['error'] = '缺少对应页面'
                    report['pages'].append(page_report)
                    continue
                geometry_a = (a_page.rect.width, a_page.rect.height, a_page.rotation)
                geometry_b = (b_page.rect.width, b_page.rect.height, b_page.rotation)
                page_report['actual_geometry'] = geometry_a
                page_report['baseline_geometry'] = geometry_b
                if geometry_a != geometry_b:
                    message = f'第{index + 1}页尺寸或旋转不一致'
                    report['structural_errors'].append(message)
                    page_report['error'] = message
                elif mode in {'all', 'visual'}:
                    a_mask, b_mask = _mask(a_page, np, pymupdf), _mask(b_page, np, pymupdf)
                    metrics, a_residual, b_residual = compare_masks(a_mask, b_mask)
                    page_report.update(metrics)
                    page_report['visual_passed'] = (
                        metrics['ink_difference_ratio'] <= config['最大墨迹差异率'] and
                        metrics['unmatched_area_pt2'] <= config['最大未匹配面积'])
                    if output and not page_report['visual_passed']:
                        diff = output / f'page_{index + 1:03d}_diff.png'
                        _write_diff(diff, a_residual, b_residual, np, Image)
                        page_report['diff_image'] = str(diff)
                    del a_mask, b_mask, a_residual, b_residual
                if geometry_a == geometry_b and mode in {'all', 'color'}:
                    a_rgb, b_rgb = _rgb(a_page, np, pymupdf), _rgb(b_page, np, pymupdf)
                    metrics, changed = compare_rgb(a_rgb, b_rgb, config['颜色通道容差'])
                    page_report.update(metrics)
                    page_report['color_passed'] = (
                        metrics['color_difference_ratio'] <= config['最大颜色差异率'] and
                        metrics['color_difference_area_pt2'] <= config['最大颜色差异面积'])
                    if output and not page_report['color_passed']:
                        path = output / f'page_{index + 1:03d}_color_diff.png'
                        _write_diff(path, changed, np.zeros_like(changed), np, Image)
                        page_report['color_diff_image'] = str(path)
                    del a_rgb, b_rgb, changed
                report['pages'].append(page_report)
    except (ValueError, requests.RequestException, OSError, RuntimeError) as error:
        raise ValueError(f'PDF比较无法完成：{error}') from error
    if mode not in {'visual', 'color'}:
        report['text_layout'] = compare_characters(all_actual, all_baseline)
    visual_pages = [p for p in report['pages'] if 'ink_pixels' in p]
    residual = sum(p['unmatched_ink_pixels'] for p in visual_pages)
    ink = sum(p['ink_pixels'] for p in visual_pages)
    report['visual_summary'] = {
        'unmatched_ink_pixels': residual,
        'ink_difference_ratio': residual / ink if ink else 0.0,
        'unmatched_area_pt2': residual * (72 / DPI) ** 2,
        'worst_page': max(visual_pages, key=lambda p: p['ink_difference_ratio'])['page'] if visual_pages else None,
    }
    if output:
        report['report_path'] = str(output / 'report.json')
    return report


def evaluate_report(report, config):
    failures = list(report['structural_errors'])
    mode = report['mode']
    if mode in {'all', 'visual'}:
        for page in report['pages']:
            if page.get('visual_passed') is False:
                failures.append(f"第{page['page']}页墨迹差异率={page['ink_difference_ratio']:.6g}，未匹配面积={page['unmatched_area_pt2']:.6g}pt²")
    if mode in {'all', 'color'}:
        for page in report['pages']:
            if page.get('color_passed') is False:
                failures.append(f"第{page['page']}页颜色差异率={page['color_difference_ratio']:.6g}，颜色差异面积={page['color_difference_area_pt2']:.6g}pt²")
    if mode not in {'visual', 'color'}:
        if report['text_unavailable_pages']:
            failures.append('部分页面无原生文字，无法完成原生文字比较（不执行OCR）')
        counts = report['text_layout']['counts']
        if counts['text_change']:
            failures.append(f"文字新增/删除/替换={counts['text_change']}字符")
        if mode in {'all', 'layout'}:
            for metric, label in [('page_flow', '最大跨页字符数'), ('line_wrap', '最大换行变化数'),
                                  ('position_shift', '最大位移字符数'), ('font_size_change', '最大字号变化字符数')]:
                if counts[metric] > config[label]:
                    failures.append(f'{metric}={counts[metric]}，{label}={config[label]:g}')
    report['passed'] = not failures
    report['failures'] = failures
    if report.get('report_path'):
        Path(report['report_path']).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    return failures
