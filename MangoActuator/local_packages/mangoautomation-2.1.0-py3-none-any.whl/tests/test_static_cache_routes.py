import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock

from playwright._impl._errors import Error, TimeoutError

from mangoautomation.uidrives.web.async_web._new_browser import AsyncWebNewBrowser
from mangoautomation.uidrives.web.sync_web._new_browser import SyncWebNewBrowser
from mangoautomation.uidrives.web.static_cache import StaticResourceCache


def cache():
    return SimpleNamespace(can_cache_request=Mock(return_value=True), read=Mock(return_value=None),
                           write=Mock(), log_failure=Mock())


class AsyncStaticCacheRouteTests(unittest.IsolatedAsyncioTestCase):
    def browser(self):
        browser = object.__new__(AsyncWebNewBrowser)
        browser.static_cache = cache()
        browser.is_header_intercept = False
        return browser

    async def test_fetch_timeout_falls_back_without_leaking_route_error(self):
        browser = self.browser()
        route = SimpleNamespace(fetch=AsyncMock(side_effect=TimeoutError('timeout')),
                                continue_=AsyncMock(), fulfill=AsyncMock())
        await browser.route_request(route, Mock(resource_type='script'))
        route.fetch.assert_awaited_once_with(timeout=StaticResourceCache.FETCH_TIMEOUT_MS)
        route.continue_.assert_awaited_once()
        route.fulfill.assert_not_awaited()

    async def test_expired_route_does_not_poison_next_browser_call(self):
        browser = self.browser()
        route = SimpleNamespace(fetch=AsyncMock(side_effect=TimeoutError('timeout')),
                                continue_=AsyncMock(side_effect=Error('Target closed')))
        await browser.route_request(route, Mock())
        self.assertEqual(browser.static_cache.log_failure.call_count, 2)

    async def test_cache_write_failure_still_returns_fetched_response(self):
        browser = self.browser()
        browser.static_cache.write.side_effect = OSError('disk full')
        response = SimpleNamespace(status=200, headers={'content-type': 'text/javascript'},
                                   body=AsyncMock(return_value=b'window.sdk = true'))
        route = SimpleNamespace(fetch=AsyncMock(return_value=response), fulfill=AsyncMock(), continue_=AsyncMock())
        await browser.route_request(route, Mock())
        route.fulfill.assert_awaited_once_with(status=200, headers=response.headers, body=b'window.sdk = true')
        route.continue_.assert_not_awaited()

    async def test_cache_hit_does_not_fetch(self):
        browser = self.browser()
        browser.static_cache.read.return_value = {'status': 200, 'body': b'cached'}
        route = SimpleNamespace(fetch=AsyncMock(), fulfill=AsyncMock())
        await browser.route_request(route, Mock())
        route.fetch.assert_not_awaited()
        route.fulfill.assert_awaited_once_with(status=200, body=b'cached')

    async def test_fallback_keeps_custom_header_interceptor(self):
        browser = self.browser()
        browser.is_header_intercept = True
        browser.wen_intercept_request = AsyncMock()
        route = SimpleNamespace(fetch=AsyncMock(side_effect=TimeoutError('timeout')), continue_=AsyncMock())
        request = Mock()
        await browser.route_request(route, request)
        browser.wen_intercept_request.assert_awaited_once_with(route, request)
        route.continue_.assert_not_awaited()


class SyncStaticCacheRouteTests(unittest.TestCase):
    def browser(self):
        browser = object.__new__(SyncWebNewBrowser)
        browser.static_cache = cache()
        browser.is_header_intercept = False
        return browser

    def test_fetch_timeout_falls_back_with_independent_timeout(self):
        browser = self.browser()
        route = Mock()
        route.fetch.side_effect = TimeoutError('timeout')
        browser.route_request(route, Mock())
        route.fetch.assert_called_once_with(timeout=StaticResourceCache.FETCH_TIMEOUT_MS)
        route.continue_.assert_called_once()
        route.fulfill.assert_not_called()

    def test_expired_route_is_contained(self):
        browser = self.browser()
        route = Mock()
        route.fetch.side_effect = TimeoutError('timeout')
        route.continue_.side_effect = Error('Target closed')
        browser.route_request(route, Mock())
        self.assertEqual(browser.static_cache.log_failure.call_count, 2)

    def test_cache_write_failure_preserves_response(self):
        browser = self.browser()
        browser.static_cache.write.side_effect = OSError('disk full')
        route = Mock()
        route.fetch.return_value = SimpleNamespace(status=200, headers={}, body=Mock(return_value=b'original'))
        browser.route_request(route, Mock())
        route.fulfill.assert_called_once_with(status=200, headers={}, body=b'original')
        route.continue_.assert_not_called()
