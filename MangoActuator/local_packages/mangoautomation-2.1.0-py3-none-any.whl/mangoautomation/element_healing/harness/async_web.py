# -*- coding: utf-8 -*-
from mangoautomation.reporting import report_automation_error
import asyncio
import time

from ..candidates import AccessibilityAgentCandidateSource, CandidateRegistry
from ..context import HealingContextBuilder
from ..models import FailedLocator
from ..observability import TraceRecorder
from ..policy import (
    AGENT_TIMEOUT_SECONDS,
    DETERMINISTIC_BUDGET_SECONDS,
    MAX_AGENT_CANDIDATES,
    MAX_CANDIDATES,
    MAX_HISTORICAL_CANDIDATES,
    AgentCircuitBreaker,
)
from ..snapshot import SnapshotRefResolver


class AsyncWebHealingRunner:
    async def run(self, harness, page, element_model, failed_expression, find_params, error=None,
                  emit_events: bool = True):
        if harness.agent:
            harness.agent.reset_attempt()
        if harness.visual_agent:
            harness.visual_agent.reset_attempt()
        started = time.perf_counter()
        context = await HealingContextBuilder.build_async(
            page, element_model, failed_expression, find_params, error, harness.test_env,
            harness.runtime_config,
        )
        smart_budget = max(0.1, context.smart_locator_timeout_seconds)
        deterministic_deadline = started + min(DETERMINISTIC_BUDGET_SECONDS, smart_budget)
        total_deadline = started + smart_budget
        visual_available = bool(
            context.visual_locator_enabled and harness.visual_agent and
            harness.visual_agent.available
        )
        visual_reserve = 0.0
        if visual_available:
            deterministic_budget = min(DETERMINISTIC_BUDGET_SECONDS, smart_budget)
            visual_reserve = min(
                max(1.0, context.visual_locator_timeout_seconds),
                max(0.0, smart_budget - deterministic_budget),
                max(8.0, smart_budget * 0.35),
            )
        agent_deadline = total_deadline - visual_reserve
        recorder = TraceRecorder(context)
        memory_started = time.perf_counter()
        try:
            memory = await asyncio.wait_for(
                harness._get_ai_info(context.element_id),
                timeout=max(0.1, deterministic_deadline - time.perf_counter()),
            )
            recorder.stage('memory', memory_started)
        except Exception as memory_error:
            await report_automation_error(harness, memory_error, 'automation:healing:async_web:run')
            memory = {}
            recorder.stage('memory', memory_started, error=str(memory_error))

        all_candidates = []
        results = []
        rejects = []

        historical_started = time.perf_counter()
        reserve_for_agent = MAX_AGENT_CANDIDATES if harness.agent and harness.agent.available else 0
        deterministic_capacity = MAX_CANDIDATES - reserve_for_agent
        historical = CandidateRegistry.historical(
            memory, element_model, failed_expression,
        )[:min(MAX_HISTORICAL_CANDIDATES, deterministic_capacity)]
        all_candidates.extend(historical)
        recorder.stage('historical_candidates', historical_started, len(historical))
        selected = await harness._verify_async(
            page, element_model, historical, find_params, results, rejects, 0,
            deadline=deterministic_deadline,
        )
        if selected:
            return await harness._finish_async(
                selected, context, recorder, all_candidates, results, rejects,
                emit_event=emit_events,
            )

        dom_started = time.perf_counter()
        dom_capacity = max(0, deterministic_capacity - len(historical))
        dom = []
        dom_error = None
        remaining = deterministic_deadline - time.perf_counter()
        if dom_capacity and remaining > 0:
            try:
                dom = await asyncio.wait_for(
                    CandidateRegistry.current_page_async(
                        page, context.expected_semantics.target_texts, failed_expression,
                    ),
                    timeout=max(0.1, remaining),
                )
                dom = dom[:dom_capacity]
            except asyncio.TimeoutError:
                dom_error = 'deterministic candidate generation budget exhausted'
                harness._append_budget_reject(rejects, dom_error)
        elif remaining <= 0:
            dom_error = 'deterministic healing budget exhausted'
            harness._append_budget_reject(rejects, dom_error)
        all_candidates.extend(dom)
        recorder.stage('current_page_candidates', dom_started, len(dom), error=dom_error)
        selected = await harness._verify_async(
            page, element_model, dom, find_params, results, rejects, len(historical),
            deadline=deterministic_deadline,
        )
        if selected:
            return await harness._finish_async(
                selected, context, recorder, all_candidates, results, rejects,
                emit_event=emit_events,
            )

        agent_context = context.model_copy(deep=True)
        known_failed = {item.loc for item in agent_context.failed_locators}
        for row in results:
            loc = row.get('loc')
            if loc and not row.get('verified') and loc not in known_failed:
                agent_context.failed_locators.append(FailedLocator(loc=loc))
                known_failed.add(loc)
        agent_started = time.perf_counter()
        agent_candidates = []
        agent_error = None
        agent_available = bool(harness.agent and harness.agent.available)
        breaker_status = AgentCircuitBreaker.status(context.element_id, context.page_url)
        recorder.trace.agent_circuit_breaker = breaker_status.to_dict()
        agent_allowed = agent_available and breaker_status.allowed
        recorder.trace.agent_called = agent_allowed
        if agent_available and not agent_allowed:
            agent_error = 'agent circuit breaker cooldown active'
            log_method = harness.log.debug if breaker_status.configuration_error else harness.log.warning
            log_method(
                f'[元素自愈Agent熔断] 跳过模型调用，元素ID={context.element_id}，'
                f'页面={context.page_url}，连续失败={breaker_status.failure_count}/'
                f'{breaker_status.threshold}，冷却剩余='
                f'{breaker_status.cooldown_remaining_seconds:.1f}s，'
                f'最近失败={breaker_status.last_error or "-"}'
            )
        elif agent_allowed:
            if breaker_status.recovery_probe:
                harness.log.info(
                    f'[元素自愈Agent熔断] 冷却结束，开始恢复探测，'
                    f'元素ID={context.element_id}，页面={context.page_url}，'
                    f'此前连续失败={breaker_status.failure_count}，'
                    f'最近失败={breaker_status.last_error or "-"}'
                )
            remaining = agent_deadline - time.perf_counter()
            if remaining <= 0:
                agent_error = 'text agent budget reserved for visual fallback'
            else:
                agent_timeout = max(0.1, min(AGENT_TIMEOUT_SECONDS, remaining))
                try:
                    agent_candidates = await asyncio.wait_for(
                        AccessibilityAgentCandidateSource(harness.agent).build_async(
                            page, agent_context, memory,
                        ),
                        timeout=agent_timeout,
                    )
                except asyncio.TimeoutError:
                    agent_error = f'agent call exceeded {agent_timeout:g}s'
                except Exception as agent_exception:
                    await report_automation_error(harness, agent_exception, 'automation:healing:async_web:run')
                    agent_error = str(agent_exception)
                if not agent_error:
                    agent_error = getattr(harness.agent, 'last_error', None)
                if not agent_error and not agent_candidates:
                    agent_error = 'agent returned no valid candidates'
                if agent_error or not agent_candidates:
                    breaker_status = AgentCircuitBreaker.failure(
                        context.element_id, context.page_url, error=agent_error,
                        configuration_error=AgentCircuitBreaker.is_configuration_error(agent_error),
                    )
                    recorder.trace.agent_circuit_breaker = breaker_status.to_dict()
                    message = (
                        f'元素ID={context.element_id}，页面={context.page_url}，'
                        f'连续失败={breaker_status.failure_count}/{breaker_status.threshold}，'
                        f'是否熔断={not breaker_status.allowed}，'
                        f'冷却={breaker_status.cooldown_remaining_seconds:.1f}s，'
                        f'原因={agent_error or "-"}'
                    )
                    if emit_events:
                        harness.log.warning(f'[元素自愈Agent失败] {message}')
                    else:
                        harness.log.debug(
                            f'[元素后台自愈] Agent未生成有效候选，固定定位仍继续重试；{message}'
                        )
                else:
                    recovered = AgentCircuitBreaker.success(context.element_id, context.page_url)
                    recorder.trace.agent_circuit_breaker = recovered.to_dict()
                    harness.log.info(
                        f'[元素自愈Agent成功] 元素ID={context.element_id}，'
                        f'页面={context.page_url}，候选数={len(agent_candidates)}，'
                        f'已清除失败计数={recovered.failure_count}'
                    )
        agent_capacity = max(0, MAX_CANDIDATES - len(all_candidates))
        agent_candidates = agent_candidates[:agent_capacity]
        all_candidates.extend(agent_candidates)
        recorder.stage('agent_candidates', agent_started, len(agent_candidates), error=agent_error)
        selected = await harness._verify_async(
            page, element_model, agent_candidates, find_params, results, rejects,
            len(historical) + len(dom),
            deadline=agent_deadline,
        )
        if selected:
            result = await harness._finish_async(
                selected, context, recorder, all_candidates, results, rejects,
                emit_event=emit_events,
            )
            if result is None and harness.agent and harness.agent.last_snapshot_id:
                await SnapshotRefResolver.clear_async(page, harness.agent.last_snapshot_id)
            return result

        visual_started = time.perf_counter()
        visual_candidates = []
        visual_error = None
        visual_allowed = visual_available
        if context.visual_locator_enabled and not visual_allowed:
            visual_error = 'vision_model_unavailable'
        elif visual_allowed:
            remaining = total_deadline - time.perf_counter()
            if remaining <= 0:
                visual_error = 'vision_budget_exhausted'
            else:
                try:
                    visual_candidates = await asyncio.wait_for(
                        harness.visual_agent.propose_async(page, agent_context, memory),
                        timeout=max(0.1, remaining),
                    )
                except asyncio.TimeoutError:
                    visual_error = 'vision request exceeded remaining smart locator budget'
                except Exception as visual_exception:
                    await report_automation_error(harness, visual_exception, 'automation:healing:async_web:run')
                    visual_error = str(visual_exception)
                if not visual_error:
                    visual_error = getattr(harness.visual_agent, 'last_error', None)
        all_candidates.extend(visual_candidates)
        recorder.stage(
            'visual_candidates', visual_started, len(visual_candidates), error=visual_error,
        )
        selected = await harness._verify_async(
            page, element_model, visual_candidates, find_params, results, rejects,
            len(historical) + len(dom) + len(agent_candidates), deadline=total_deadline,
        )
        if selected:
            return await harness._finish_async(
                selected, context, recorder, all_candidates, results, rejects,
                emit_event=emit_events,
            )
        if visual_error:
            harness._append_reject(rejects, visual_error)
        result = await harness._exhausted_async(
            context, recorder, all_candidates, results, rejects, emit_event=emit_events,
        )
        if harness.agent and harness.agent.last_snapshot_id:
            await SnapshotRefResolver.clear_async(page, harness.agent.last_snapshot_id)
        if harness.visual_agent and harness.visual_agent.last_snapshot_id:
            await SnapshotRefResolver.clear_async(page, harness.visual_agent.last_snapshot_id)
        return result
