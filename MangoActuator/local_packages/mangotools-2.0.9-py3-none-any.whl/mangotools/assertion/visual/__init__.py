# -*- coding: utf-8 -*-
from ._pdf_comparison import PdfComparisonAssertion


class FileVisualAssertion(PdfComparisonAssertion):
    """文件视觉识别"""


__all__ = ['FileVisualAssertion', 'PdfComparisonAssertion']
