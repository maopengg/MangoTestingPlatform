import unittest

from mangotools.assertion import MangoAssertion
from mangotools.data_processor import JsonTool, RegexTool
from mangotools.exceptions import MangoToolsError


class ExtractionErrorTests(unittest.TestCase):
    def test_invalid_jsonpath_is_not_reported_as_no_match(self):
        for expression in ('data.id', '$.', '$..', '$...id', '$[', "$['name]", '$[]',
                           '$[1,,2]', '$[0:3:0]', '$[?(@.id = 1)]', '$[?()]',
                           '$[(@.length-)]', '$.a)', '$[??]'):
            for source in ({}, {'data': []}):
                with self.subTest(expression=expression, source=source):
                    with self.assertRaises(MangoToolsError) as raised:
                        JsonTool.get_json_path_value(source, expression)
                    self.assertEqual(raised.exception.code, 3005)
                    self.assertNotIn('未匹配到数据', raised.exception.msg)

    def test_valid_jsonpath_grammar_and_filters_are_preserved(self):
        for expression in ('$', '$.data', '$..id', '$[*]', '$[0]', '$[-1]', '$[1:3]',
                           "$['name']", '$["a]b"]', '$["a[b"]', '$[0,1]',
                           '$.items[?(@.price < 10)].id', '$[(@.length-1)]'):
            with self.subTest(expression=expression):
                self.assertEqual(JsonTool.validate_json_path_expression(expression), expression)
        source = {'items': [{'id': 1, 'price': 5}, {'id': 2, 'price': 15}]}
        self.assertEqual(JsonTool.get_json_path_value(source, '$.items[?(@.price < 10)].id'), 1)

    def test_valid_no_match_remains_distinct(self):
        with self.assertRaises(MangoToolsError) as raised:
            JsonTool.get_json_path_value({'code': 200}, '$.data')
        self.assertEqual(raised.exception.code, 3003)
        self.assertIn('不存在字段【data】', raised.exception.msg)
        self.assertEqual(JsonTool.match_json_path([], '$[*]'), [])

    def test_jsonpath_assertion_config_errors_use_our_error_class(self):
        for method in ('p_json_path_exists', 'p_json_path_not_exists', 'p_json_path_not_empty'):
            for expression in ('$.data[', '$.', None, ''):
                with self.subTest(method=method, expression=expression):
                    with self.assertRaises(MangoToolsError):
                        MangoAssertion().ass(method, {}, expression)

    def test_regex_syntax_errors_have_chinese_reason_and_position(self):
        for expression, reason in (('[abc', '方括号'), ('(abc', '圆括号'), ('*abc', '量词'),
                                   ('[z-a]', '字符范围'), (r'\k', '转义'),
                                   (r'(?<=a+)b', '固定长度')):
            with self.subTest(expression=expression):
                with self.assertRaises(MangoToolsError) as raised:
                    RegexTool.compile(expression)
                self.assertEqual(raised.exception.code, 3062)
                self.assertIn(reason, raised.exception.msg)
                self.assertIn(expression, raised.exception.msg)
        with self.assertRaises(MangoToolsError):
            RegexTool.compile('a{1,999999999999999999999}')

    def test_regex_invalid_types_use_our_error_class(self):
        for expression in (None, '', 1, [], b'abc'):
            with self.subTest(expression=expression), self.assertRaises(MangoToolsError):
                RegexTool.compile(expression)
        for source in (None, {}, [], 1):
            with self.subTest(source=source), self.assertRaises(MangoToolsError) as raised:
                RegexTool.search(source, 'a')
            self.assertEqual(raised.exception.code, 3063)

    def test_regex_extract_shapes_and_no_match(self):
        for source, expression, expected in (
            ('id=42', r'\d+', '42'), ('id=42', r'id=(\d+)', '42'),
            ('a=1,b=2', r'a=(\d+),b=(\d+)', ['1', '2']),
            ('b', '(a)?b', None), ('', '^$', ''), (' ', ' ', ' '),
        ):
            with self.subTest(expression=expression):
                match = RegexTool.search(source, expression)
                self.assertIsNotNone(match)
                self.assertEqual(RegexTool.extracted_value(match), expected)
        self.assertIsNone(RegexTool.search('abc', r'\d+'))
