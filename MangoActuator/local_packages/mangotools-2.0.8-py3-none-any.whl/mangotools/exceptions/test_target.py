from mangotools.exceptions import MangoToolsError


class TestTargetResolutionError(MangoToolsError):
    def __init__(self, message):
        super().__init__(code=10990, msg=message)
